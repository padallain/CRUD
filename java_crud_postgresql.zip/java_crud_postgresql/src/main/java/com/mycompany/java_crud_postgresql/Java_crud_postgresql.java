

package com.mycompany.java_crud_postgresql;

public class Java_crud_postgresql {

    public static void main(String[] args) {
       VistaAlumnos objetoVista= new VistaAlumnos();
       objetoVista.setVisible(true);
       
       
    }
}
